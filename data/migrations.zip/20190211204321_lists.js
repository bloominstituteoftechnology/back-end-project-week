
exports.up = function(knex, Promise) {
    return knex.schema.createTable('lists', lists => {
        lists.increments('id');
  
        lists
        .string('title', 128)
        .notNullable()
        .unique();
        lists.string('list', 128).notNullable();
        lists.integer('notes_id').unsigned();
        lists.foreign('notes_id').references('id').on('notes');
    });
  };
  
  exports.down = function(knex, Promise) {
    return knex.schema.dropTableIfExists('notes');
  };
  