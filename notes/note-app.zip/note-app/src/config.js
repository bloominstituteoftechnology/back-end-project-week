module.exports = {
  appK: 'com.reactnotes',
  secret:
    'adsafkjoajfiearbfnewfhawfhuawhf19847y1he9he219hd1h[d/a/fa/dfa/d2193u',
};
