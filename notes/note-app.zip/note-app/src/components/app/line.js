import React from 'react';

const Line = _ => {
  return <div className="Line" />;
};

export default Line;
