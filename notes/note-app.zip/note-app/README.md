A sample for a note project
